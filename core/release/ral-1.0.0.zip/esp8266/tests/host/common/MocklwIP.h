
#ifndef __MOCKLWIP_H
#define __MOCKLWIP_H

extern "C"
{
#include <user_interface.h>
#include <lwip/netif.h>

    extern netif netif0;

}  // extern "C"

#endif  // __MOCKLWIP_H
