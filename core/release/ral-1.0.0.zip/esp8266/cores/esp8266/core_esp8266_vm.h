#ifdef __cplusplus
extern "C" {
#endif

extern void install_vm_exception_handler();


#ifdef __cplusplus
};
#endif

